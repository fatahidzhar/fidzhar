/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React from 'react';
import {
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
  Image,
} from 'react-native';

import {
  Header,
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';

const App: () => React$Node = () => {
  return (
    <>
      <StatusBar barStyle="dark-content" />
        <ScrollView
          contentInsetAdjustmentBehavior="automatic"
          style={styles.scrollView}>
          <Header />
          {global.HermesInternal == null ? null : (
            <View style={styles.engine}>
              <Text style={styles.footer}>Engine: Hermes</Text>
            </View>
          )}
          <View style={styles.body}>
            <View style={styles.sectionContainer}>
              <Text style={styles.sectionTitle}>Jadwal Hari Ini!</Text>
                <View style={styles.BoxPadding}>
                  <View style={styles.BoxJadwal1}>
                    <Text style={styles.NotifJadwal1}>
                      Test
                    </Text>
                  </View>
                  <View style={styles.BoxJadwal2} />
                  <View style={styles.BoxJadwal3} />
                  <View style={styles.BoxJadwal4} />
                </View>
            </View>
            <View style={styles.sectionContainer}>
              <Text style={styles.sectionTitle}>Notifikasi!</Text>
                <View style={styles.Notif}>
                    <ReloadInstructions />
                  </View>
                </View>
          </View>
        </ScrollView>
      <View style={styles.BottomNavigation}>
        <View style={styles.NameItems}>
          <View style={styles.IconItems}>
            <Image source={require('./icon/iconNavHome-Active.png')} />
          </View>
            <Text style={{color: '#616CFF'}}>Home</Text>
        </View>
        <View style={styles.NameItems}>
          <View style={styles.IconItems}>
            <Image source={require('./icon/iconNavJadwal.png')} />
          </View>
            <Text style={styles.TextItems}>Jadwal</Text>
        </View>    
        <View style={styles.NameItems}>
          <View style={styles.IconItems}>
            <Image source={require('./icon/iconNavGraph.png')} />
          </View>
            <Text style={styles.TextItems}>Aktifitas</Text>
        </View>
        <View style={styles.NameItems}>
          <View style={styles.IconItems}>
            <Image source={require('./icon/iconNavProfil.png')} />
          </View>
            <Text style={styles.TextItems}>Profil</Text>
        </View>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  scrollView: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  
  engine: {
    position: 'absolute',
    right: 0,
  },
  
  body: {
    marginTop: -50,
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    backgroundColor: Colors.white,
    alignItems: 'center',
    flex: 1,
  },

  sectionContainer: {
    flex: 1,
    marginTop: 25,
    paddingHorizontal: 24,
  },

  sectionTitle: {
    fontSize: 24,
    fontWeight: '600',
    marginLeft: 15,
    paddingBottom: 20,
    color: Colors.black,
  },
  
  BoxPadding: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'space-around',
  },

  BoxJadwal1: {
    width: 370,
    height: 80,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    backgroundColor: '#BABFFF',
  },

  BoxJadwal2: {
    width: 370,
    height: 80,
    marginTop: 10,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    backgroundColor: '#616CFF',
  },

  BoxJadwal3: {
    width: 370,
    height: 80,
    marginTop: 10,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    backgroundColor: '#BABFFF',
  },

  BoxJadwal4: {
    width: 370,
    height: 80,
    marginTop: 10,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    backgroundColor: '#616CFF',
  },

  Notif: {
    width: 370,
    height: 80,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    backgroundColor: '#FFFFFF',
  },

  highlight: {
    fontWeight: '700',
  },

  BottomNavigation: {
    flexDirection: 'row',
    height: 65,
    backgroundColor: '#FFFFFF',
  },

  NameItems: {
    backgroundColor: '#FFFFFF', 
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 4,
    flex: 1,
  },

  TextItems: {
    color: '#88ACFF',
    fontSize: 14,
  },

  IconItems: {
    width: 30, 
    height: 30,
  },

});

export default App;
